/*
 DEVEL IN PROGRESS
*/

#ifndef Arduino_h
#define Arduino_h

#include <8051.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>

#include <pins_arduino.h>

//#include <pgmspace.h>
//#include <io.h>
//#include <interrupt.h>
//#include "binary.h"

#define HIGH 0x1
#define LOW  0x0

#define INPUT 0x0
#define OUTPUT 0x1
#define INPUT_PULLUP 0x2

#ifndef PI

#define PI 3.1415926535897932384626433832795
#define HALF_PI 1.5707963267948966192313216916398
#define TWO_PI 6.283185307179586476925286766559

#endif
#define DEG_TO_RAD 0.017453292519943295769236907684886
#define RAD_TO_DEG 57.295779513082320876798154814105
#define EULER 2.718281828459045235360287471352

#define SERIAL  0x0
#define DISPLAY 0x1

#define LSBFIRST 0
#define MSBFIRST 1

#define CHANGE 1
#define FALLING 2
#define RISING 3

// undefine stdlib's abs if encountered
#ifdef abs
#undef abs
#endif

#define min(a,b) ((a)<(b)?(a):(b))
#define max(a,b) ((a)>(b)?(a):(b))
#define abs(x) ((x)>0?(x):-(x))
#define constrain(amt,low,high) ((amt)<(low)?(low):((amt)>(high)?(high):(amt)))
#define round(x)     ((x)>=0?(long)((x)+0.5):(long)((x)-0.5))
#define radians(deg) ((deg)*DEG_TO_RAD)
#define degrees(rad) ((rad)*RAD_TO_DEG)
#define sq(x) ((x)*(x))

#define interrupts() sei()
#define noInterrupts() cli()

#define clockCyclesPerMicrosecond() ( F_CPU / 1000000L )
#define clockCyclesToMicroseconds(a) ( (a) / clockCyclesPerMicrosecond() )
#define microsecondsToClockCycles(a) ( (a) * clockCyclesPerMicrosecond() )

#define lowByte(w) ((uint8_t) ((w) & 0xff))
#define highByte(w) ((uint8_t) ((w) >> 8))

#define bitRead(value, bit) (((value) >> (bit)) & 0x01)
#define bitSet(value, bit) ((value) |= (1UL << (bit)))
#define bitClear(value, bit) ((value) &= ~(1UL << (bit)))
#define bitToggle(value, bit) ((value) ^= (1UL << (bit)))
#define bitWrite(value, bit, bitvalue) ((bitvalue) ? bitSet(value, bit) : bitClear(value, bit))

#ifndef _NOP
#define _NOP() do { __asm__ volatile ("nop"); } while (0)
#endif

#define bit(b) (1UL << (b))

void setup(void);
void loop(void);

// Arduino primaries functions

int main(void) {
    setup();
    while (1) loop();
}

// Fonction de délai
void delay(unsigned int ms) {
    unsigned int i, j;
    for (i = 0; i < ms; i++) {
        for (j = 0; j < 123; j++) {
            // NOP pour un délai de 1 ms approximatif avec une horloge de 12 MHz
        }
    }
}
// Fonction pour calculer la puissance
unsigned char pow(unsigned char base, unsigned char exp) {
    unsigned char result = 1;
    unsigned char i;
    for (i = 0; i < exp; i++) {
        result *= base;
    }
    return result;
}

void pinMode(unsigned char pin, unsigned char state) {
  if (pin<8) {
     P1 &= ~pow(2,state);P1|= pow(2,state);
  }
  if ((pin>7) && (pin<11)) {
     P3 &= ~pow(2,state);P3|= pow(2,state);
  }
  if ((pin>10) && (pin<19)) {
     P2 &= ~pow(2,state);P2|= pow(2,state);
  }
  if ((pin>18)) {
     P0 &= ~pow(2,state);P0|= pow(2,state);
  }
}
void digitalWrite(unsigned char pin, unsigned char state) {
  if (pin<8) {
     P1 &= ~pow(2,state);P1|= pow(2,state);
  }
  if ((pin>7) && (pin<11)) {
     P3 &= ~pow(2,state);P3|= pow(2,state);
  }
  if ((pin>10) && (pin<19)) {
     P2 &= ~pow(2,state);P2|= pow(2,state);
  }
  if ((pin>18)) {
     P0 &= ~pow(2,state);P0|= pow(2,state);
  }
}

/* TODO
Serial.begin
Serial.print
tone
 */
#endif
