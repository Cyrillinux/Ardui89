/**/

void _8051_init_(void) {}


