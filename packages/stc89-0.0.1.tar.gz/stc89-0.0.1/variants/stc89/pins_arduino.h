/*
 * Under GPL / DISCLAIMER OF ALL WARRANTIES *
*/

#ifndef Pins_Arduino_h
#define Pins_Arduino_h

#include <8051.h>

#define NUM_DIGITAL_PINS            27
#define NUM_ANALOG_INPUTS           8

// 8051/89C51
/*    Arduino 8051 pinout
 D                                                                D  A
             ____________________________________
            |                                    |
 0 P1.0 ----|  1     P1.0           VCC       40 |---- VCC
 1 P1.1 ----|  2     P1.1           P0.0      39 |---- P0.0 (AD0) 26 A7
 2 P1.2 ----|  3     P1.2           P0.1      38 |---- P0.1 (AD1) 25 A6
 3 P1.3 ----|  4     P1.3           P0.2      37 |---- P0.2 (AD2) 24 A5
 4 P1.4 ----|  5     P1.4           P0.3      36 |---- P0.3 (AD3) 23 A4
 5 P1.5 ----|  6     P1.5           P0.4      35 |---- P0.4 (AD4) 22 A3
 6 P1.6 ----|  7     P1.6           P0.5      34 |---- P0.5 (AD5) 21 A2
 7 P1.7 ----|  8     P1.7           P0.6      33 |---- P0.6 (AD6) 20 A1
   RST  ----|  9     RST            P0.7      32 |---- P0.7 (AD7) 19 A0
   RXD  ----| 10     RXD            EA        31 |---- EA
   TXD  ----| 11     TXD            ALE       30 |---- ALE
   INT0 ----| 12     INT0           PSEN      29 |---- PSEN
   INT1 ----| 13     INT1           P2.7      28 |---- P2.7 (A15) 18
   T0   ----| 14     T0             P2.6      27 |---- P2.6 (A14) 17
   T1   ----| 15     T1             P2.5      26 |---- P2.5 (A13) 16
   WR   ----| 16     WR             P2.4      25 |---- P2.4 (A12) 15
   RD   ----| 17     RD             P2.3      24 |---- P2.3 (A11) 14
 8 P3.0 ----| 18     P3.0 (MOSI)    P2.2      23 |---- P2.2 (A10) 13
 9 P3.1 ----| 19     P3.1 (MISO)    P2.1      22 |---- P2.1 (A9)  12
10 P3.2 ----| 20     P3.2 (SCK)     P2.0      21 |---- P2.0 (A8)  11
            |____________________________________|
*/

#define MOSI 8
#define MISO 9
#define SCK 10

//#define SDA 18
//#define SCL 19

#define LED_BUILTIN 11

#define A0 19
#define A1 20
#define A2 21
#define A3 22
#define A4 23
#define A5 24
#define A6 25
#define A7 26

#define SERIAL_PORT_MONITOR   Serial
#define SERIAL_PORT_HARDWARE  Serial

#endif
