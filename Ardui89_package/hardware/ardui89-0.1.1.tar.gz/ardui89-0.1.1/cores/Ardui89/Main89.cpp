/*
 * DISLAIMER OF ALL WARRANTIES *
 * Cyril BARBATO 2024
 */
#include <Main89.h>
// Arduino primaries functions
// MAIN
int main(void) {
    setup();
    while (1) loop();
}

