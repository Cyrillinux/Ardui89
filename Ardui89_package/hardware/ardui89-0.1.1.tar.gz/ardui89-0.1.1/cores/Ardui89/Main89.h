/*
 * DISLAIMER OF ALL WARRANTIES *
 * Cyril BARBATO 2024
 */

#ifndef _MAIN89_H_
#define _MAIN89_H_

// Prototypes
void setup(void);
void loop(void);

#endif
