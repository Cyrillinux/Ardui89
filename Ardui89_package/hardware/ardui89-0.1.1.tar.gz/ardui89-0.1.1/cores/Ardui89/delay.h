/*
 * DISLAIMER OF ALL WARRANTIES *
 * Cyril BARBATO 2024
 */
void delay(unsigned int ms);
void delayMicroseconds(unsigned int us);


