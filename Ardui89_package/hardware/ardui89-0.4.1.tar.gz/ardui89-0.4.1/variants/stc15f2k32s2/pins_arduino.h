// Equivalent AVR memory prog affectation
#define PROGMEM __code
