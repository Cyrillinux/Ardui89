// Not code / juste for examples libraries
